class Node:
    def __init__(self,data):
        self.data=data
        self.prev=None
        self.next=None
class dll:
    def __init__(self):
        self.head=None
    def display(self):
        if self.head is None:
            print("linked list empty")
        else:
            temp=self.head
            while temp:
                print(temp.data,"->",end=" ")
                temp=temp.next
            
            while temp:
                print(temp.data,"->",end=" ")
                temp=temp.prev
    def insert_at_begin(self,data):
        newnode=Node(data)
        newnode.next=self.head
        self.head.prev=newnode
        self.head=newnode
    def insert_at_end(self,data):
        newnode=Node(data)
        temp=self.head
        while temp.next is not None:
            temp=temp.next
        temp.next=newnode
        newnode.prev=temp
obj=dll()
n1=Node(10)
obj.head=n1
n2=Node(20)
n2.prev=n1
n1.next=n2
n3=Node(30)
n2.next=n3
n3.prev=n2
n4=Node(40)
#n4.prev=n3
n3.next=n4
n4.prev=n3
n5=Node(50)
n4.next=n5
n5.prev=n4
obj.insert_at_begin(100)
obj.insert_at_end(300)
obj.display()

        