from queue import LifoQueue
s=LifoQueue(maxsize=3)
print(s.qsize())
s.put('a')
s.put('b')#push
s.put('c')
print("queue is full:",s.full())
print("queue size:",s.qsize())
print("popped element is:",s.get())
print("popped element is:",s.get())#pop
print("popped element is:",s.get())
print("queue is empty:",s.empty())