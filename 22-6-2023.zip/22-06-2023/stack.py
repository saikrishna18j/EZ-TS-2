stack=[]
def push():
    element=int(input("enter element:"))
    stack.append(element)
def pop():
    if not stack:
        print("stack empty")
    else:
        pop=stack.pop()
        print("removed element is:",pop)
def display():
        print(stack)
def peek():
    if not stack:
        print("stack empty")
    else:
        print("peek element is:",stack.pop())
while 1:
    print("1.push 2.pop 3.display 4.peek 5.exit")
    print("select option:")
    option=int(input())
    if option==1:
        push()
    elif option==2:
        pop()
    elif option==3:
        display()
    elif option==4:
        peek()                                                                                           
    elif option==5:
        break
    else:
        print("invalid option")
