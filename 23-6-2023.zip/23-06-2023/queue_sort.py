#append elements (key,data)
#key:priority
stu=[]
stu.append((1,"pavan"))
stu.append((5,"vinay"))
stu.append((4,"saiganesh"))
stu.sort(reverse = True)
print(stu)
print("orginal queue")
while stu:
    print(stu.pop())